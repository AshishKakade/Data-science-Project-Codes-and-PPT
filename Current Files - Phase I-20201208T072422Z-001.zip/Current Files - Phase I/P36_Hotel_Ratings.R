#################### PROJECT P36- Hotel Rating Classification ###
### 
###############  TEXT MINING 

'''
Business problem:  
To perform sentiment analysis on HOTEL reviews
'''

# lets do some pre-processing before doing analysis

# install / load required libraries
library(tm) # for text mining
library(wordcloud2) # to build word cloud
library(wordcloud) # word cloud generator
library(SnowballC) # for text stemming or lemmatization
library(textstem) # for text stemming or lemmatization
library(RColorBrewer) # for color palettes  

# Importing HOTEL reviews data
hotel <- read.csv("E:\\1 P36 PROJECT\\Original Datasets\\train (2).csv")
class(hotel) # now its a dataframe
names(hotel)
dim(hotel) # 14343     3
head(hotel$Review,2)
head(hotel$Rating)

x <- as.character(hotel$Review) # converting the reviews column to character
class(x) # from dataframe converted to character type
x <- iconv(x, "UTF-8") # some special characters may not be understood by r.
# so converting all to UTF-8 which is a standard format, so can understand it

# loading the data as a corpus
x <- Corpus(VectorSource(x))
inspect(x[1:2])

x1 <- tm_map(x, tolower) # converting to lower case
inspect(x1[5:7])
x1 <- tm_map(x1, removeNumbers) # removing  numbers
x1 <- tm_map(x1, removePunctuation) # removing punctuations

x1 <- tm_map(x1, removeWords, stopwords('english')) # removing stopwords
x1 <- tm_map(x1, stripWhitespace)
x1 <- lemmatize_words(x1) # text stemming
inspect(x1[5:7])
# x1 <- tm_map(x1, stemDocument)

#### Term Document Matrix
## Converting unstructured data to structured format using TDM
tdm <- TermDocumentMatrix(x1)
class(tdm)
tdm <- as.matrix(tdm) # getting 99395 elements
class(tdm) # now converted from TDM to matrix form

# frequency
v <- sort(rowSums(tdm), decreasing = TRUE)
d <- data.frame(word=names(v) , freq=v)
dim(d) # 59137     2, we have got 59137 terms
head(d, 10) # top-ten words
head(d,50)

## barplot
w <- rowSums(tdm)
w_sub <- subset(w, w>=5000)
barplot(w_sub, las=3, col=rainbow(20))

x1 <- tm_map(x1, removeWords, "hotel") # removing other common  words
x1 <- tm_map(x1, stripWhitespace)


tdm <- TermDocumentMatrix(x1)
tdm <- as.matrix(tdm)  
w1 <- rowSums(tdm)
w_sub1 <- subset(w1, w>=5000)
barplot(w_sub1, las=3, col=rainbow(30))

v1 <- sort(rowSums(tdm), decreasing = TRUE)
d1 <- data.frame(word=names(v1) , freq=v1)
head(d1,30)

## word cloud
# with all the words
w2 <- subset(w1, w1>=500) # words occuring >500 times 
windows()
wordcloud(words=names(w2), freq=w2, random.order=F, colors=rainbow(20), rot.per=0.3)
# wordcloud(words=names(w1), freq=w1, random.order=F, colors=rainbow(20), scale=c(2,.2), rot.per=0.3)
'''
The words great, good, (excellent, nice and helpful) have occurred more number of 
times, this shows many users have liked the hotel and their service.
But we should also know in which context the word is actually used
Lets see an example, the word great ,
1. great location great location 5 mins subway takes way blommingdales ....
2. great time booked trip breezes apple vacations highly recommend 
3. great place, villa ixora good quiet location, walk 
# the customers have really liked the hotels

#### To visualize positive and negative words separately in the reviews
### Loading positive and negative dictionaries
'''

pos.words<- scan(file.choose(), what="character",comment.char=";") # reads from the file positive-words.txt 2006 words
neg.words <- scan(file.choose(), what="character",comment.char = ";") # reads from the file negative-words.txt 4783 items
# pos.words <- c(pos.words,"wow","kudos","hurray") # including our own positive words

# Positive word cloud
pos.matches <- match(names(w1), c(pos.words))
pos.matches <- !is.na(pos.matches)
freq_pos_words <- w1[pos.matches]
freq_pos_words
names_freq_pos_words <- names(freq_pos_words)
window()
wordcloud(names_freq_pos_words, freq_pos_words, colors=rainbow(20))
# wordcloud(names_freq_pos_words, freq_pos_words, colors=rainbow(20),scale=c(3.5,.2))

neg.matches <- match(names(w1), c(neg.words))
neg.matches <- !is.na(neg.matches)
freq_neg_words <- w1[neg.matches]
freq_neg_words[1:20]
names_freq_neg_words <- names(freq_neg_words)
wordcloud(names_freq_neg_words, freq_neg_words, colors=brewer.pal(8,"Dark2"))

## Association between words
# find words that are highky correlated with other words
tdm <- TermDocumentMatrix(x1)
findAssocs(tdm, c("great"), corlimit =0.20)
#  beach   time   food really    bar    day   pool people    fun   just resort 
#  0.27   0.26   0.25   0.23   0.23   0.22   0.22   0.22   0.21   0.21   0.21 
findAssocs(tdm, c("good"), corlimit =0.30)
#   food  beach people buffet 
#    0.36   0.35   0.30   0.30 
findAssocs(tdm, "beware", corlimit = 0.17)
#     ballons     damnthe      dripon     lenient       macoa shoplifting        soin 
#      0.22        0.22        0.22        0.22        0.22        0.22        0.22 
findAssocs(tdm, c("cold"), corlimit =0.10)

########## Assignment Text Mining - Emotion Mining of Hotel reviews 

## Loading required packages
library("syuzhet")
library(lubridate,ggplot2)
library(ggplot2)
library(scales)
library(dplyr)
library(reshape2)

# hotel review dataset
txt <- as.character(hotel$Review) # converting the reviews column to character
txt <- iconv(txt, "UTF-8")
class(txt) # from dataframe converted to character type
txt[3:5]

#get sentences for every review
example<-get_sentences(txt) 
example[1:5] 
nrc_data<-get_nrc_sentiment(example) # for each sentence apply nrc-sentiment
example[1:5]
nrc_data[1:5,]

# Bar plot for emotion mining
windows()
barplot(colSums(nrc_data), las = 1, col = rainbow(10), ylab = 'Count', main = 'Emotion scores')
# we see that the reviews are more of positive sentiments and very less of negative sentiments

# We have sentiments from various dictionaries: NRC, AFINN and BING
sentiment_bing<-get_sentiment(example,method="bing")
sentiment_afinn<-get_sentiment(example,method="afinn")
sentiment_nrc<-get_sentiment(example,method="nrc")

sum(sentiment_bing)
mean(sentiment_bing)
summary(sentiment_bing)

sum(sentiment_afinn)
mean(sentiment_afinn)
summary(sentiment_afinn)

sum(sentiment_nrc)
mean(sentiment_nrc)
summary(sentiment_nrc)
# the mean and range of emotions using Bing method is the least compared to the other two
# afinn method has the highest sum, mean and range

# Plotting barplot for the emotions
windows()
plot(sentiment_bing,type='l',main='Plot trajectory',xlab='Narative time',ylab='Emotional valence')
abline(h=0,color='red')
# most are above zero line, positive values

# Getting smooth curve
##Shape smoothing and normalization using a Fourier based transformation and low pass filtering is achieved using the get_transformed_values function as shown below.
ft_values <- get_transformed_values(
  sentiment_bing, 
  low_pass_size = 3, 
  x_reverse_len = 100,
  padding_factor = 2,
  scale_vals = TRUE,
  scale_range = FALSE
)

plot(
  ft_values, 
  type ="l", 
  main ="Hotel reviews using Transformed Values", 
  xlab = "Narrative Time", 
  ylab = "Emotional Valence", 
  col = "red"
)
# using fourier transform we have obtained a smooth curve. from this we can find that
# over a period of time, the reviews have changed from more negative to more positive
# to less positive and in the end again more negative. But for a great extent the 
# emotions are positive

#Most Negative and Positive reviews
negative<-example[which.min(sentiment_nrc)]
negative 
# pros nice/posh bar/lounge area frontgreat ....  cons poor security ... camera stolen 

# the above sentence is considered as the most negative review using nrc

example[which.min(sentiment_bing)]
#  traveler beware worse hotel not all-inclusive want start saying worse vacation 


positive<-example[which.max(sentiment_nrc)]
positive
# paradise resort, scottish couple stayed .... nice touch, room amazing clean tidy 
# maids really great job ...

# the above sentence is considered as the most positive review using nrc


'''
CONCLUSIONS

We have used hotel reviews for analysis.
We have pre-processed the data. We have then found the top-ten words used in the reviews.

We have built Term-document-matrix and constructed the word cloud. We have also built
the positive and negative word clouds.

We have also tried to find the association between some frequently occuring words 
to understand the customers" view point.

We have done emotion mining using the hotel reviews. 
We find that most of the customers share positive emotions about the hotels.
'''
