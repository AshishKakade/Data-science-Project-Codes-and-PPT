import math
import numpy as np
import requests
import pandas as pd
from bs4 import BeautifulSoup

import re
import nltk
from nltk.corpus import stopwords
from nltk.stem import WordNetLemmatizer

from vaderSentiment.vaderSentiment import SentimentIntensityAnalyzer

import seaborn as sns
import matplotlib.pyplot as plt

from PIL import Image
from wordcloud import WordCloud,ImageColorGenerator

data = pd.read_csv("E://Data Science//Project//train.csv")

print(data.head())

def preprocessing(data):
    data['Rating']=data['Rating'].replace({'1':'VERY NEGATIVE','2':'NEGATIVE','3':'NEUTRAL','4':'POSITIVE','5':'VERY POSITIVE'})
    lemmit= WordNetLemmatizer()
    tokens=[]
    for i in range(len(data)):
        reviews = re.sub('[^a-zA-Z]', ' ', data['Review'][i])
        reviews=re.sub(' +',' ',reviews)
        reviews = reviews.lower()
        reviews= re.sub(r'(.)\1+', r'\1\1',reviews)
        reviews = reviews.split()
        reviews= [lemmit.lemmatize(word) for word in reviews if not word in stopwords.words('english')]
        reviews= ' '.join(reviews)
        tokens.append(reviews)
    for x in range(len(tokens)):
        data=data.replace(to_replace=data['Review'][x],value=tokens[x])
    positive_words=[]
    negative_words=[]
    
    def Vader(reviews):    
        print(sentiment)
        reviews=reviews.split()
        words=SentimentIntensityAnalyzer()
    
        for i in reviews:
            if(words.polarity_scores(i)['compound'])>=0.01:
                positive_words.append(i)
            
            elif(words.polarity_scores(i)['compound'])<0.01 and (words.polarity_scores(i)['compound'])>=0.01:
                pass
            elif(words.polarity_scores(i)['compound'])<=0.01:
                negative_words.append(i)

    data['Review'].apply(vader)
    return data,positive_words,negative_words
    
def Visualization(data,positive_words,negative_words):
    corpus=[]
    corpus_positive=[]
    corpus_negative=[]
    #Wordcloud for whole corpus
        
    for i in range(len(data)):
        words=nltk.word_tokenize(data['Review'][i])
        corpus.append(words)
    wordcloud=WordCloud(background_color="black").generate(str(corpus))
    plt.figure(figsize=[20,20])
    plt.imshow(wordcloud)
    #plt.axis("off")
    plt.show()
        
#WordCloud for Postive words
    for pos in data['Review']:
        pos=pos.split()
        pos_new=[ z for z in pos if z in positive_words]
        corpus_positive.append(pos_new)
    wordcloud_positive=WordCloud(background_color="black").generate(str(corpus_positive))
    plt.figure(figsize=[20,20])
    plt.imshow(wordcloud_positive)
    #plt.axis("off")
    plt.show()

#WordCloud for Negative words
    for neg in data['Review']:
        neg=neg.split()
        neg_new=[ z for z in neg if z in negative_words]
        corpus_negative.append(neg_new)
    wordcloud_negative=WordCloud(background_color="black").generate(str(corpus_negative))
    plt.figure(figsize=[20,20])
    plt.imshow(wordcloud_negative)
    #plt.axis("off")
    plt.show()


    sns.countplot(data['Rating'],order=data['Rating'].value_counts().index,palette='dark')
    plt.title('Count Of Each Ratings ')
    plt.show()

sns.barplot(x=data['Rating'].value_counts(normalize=True).index,y=data['Rating'].value_counts(normalize=True)*100,palette='colorblind')
plt.xlabel('Rating')
plt.ylabel('Percentage')
plt.title('Percentage of Ratings')
plt.show()